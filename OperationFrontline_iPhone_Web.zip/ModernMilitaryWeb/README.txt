VERSION WEB MOBILE
Ouvre index.html avec un navigateur compatible WebGL.
Sur iPhone, le moyen le plus simple est de publier ce dossier sur un hébergeur statique puis d'ouvrir le lien dans Safari.
La page utilise Three.js depuis un CDN, donc une connexion Internet est nécessaire au chargement.
